# RifaJá — starter full-stack

Projeto inicial para o RifaJá: frontend React/Vite, Firebase Authentication + Firestore, Cloud Functions e estrutura de integração PIX.

## Requisitos
- Node.js 20+
- Projeto Firebase
- Firebase CLI (`npm install -g firebase-tools`)
- Um provedor de pagamento PIX com API e webhooks para pagamentos reais

## Executar frontend
```bash
npm install
cp .env.example .env
# Preencha as configurações públicas do Firebase no .env
npm run dev
```

## Publicar funções Firebase
```bash
npm install
cd functions && npm install && cd ..
firebase login
firebase use --add
firebase deploy --only firestore:rules,functions
```

## Segurança / configuração obrigatória
1. Ative Email/Password em Firebase Authentication.
2. Crie o primeiro usuário proprietário no Firebase Authentication.
3. Atribua a ele a custom claim `admin: true` por um procedimento administrativo confiável usando Firebase Admin SDK em ambiente seguro. Nunca coloque service-account JSON no frontend ou no repositório.
4. Configure segredos de pagamento com Firebase Functions secrets, seguindo a documentação do seu provedor.
5. Complete e teste a função de criação de cobrança PIX e o webhook para o provedor escolhido antes de aceitar pagamentos reais.
6. Configure e teste e-mail transacional, políticas de privacidade, termos e requisitos legais aplicáveis antes de operar.
7. Firebase Spark (gratuito) tem limites e não inclui todos os recursos de backend; confira preços e limites atuais do Firebase/Google Cloud.

Este starter **não** confirma pagamentos reais por conta própria. A criação de cobrança e validação de webhook são pontos de integração deliberadamente bloqueados até configurar um provedor real.
