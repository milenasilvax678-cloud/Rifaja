import React, { useEffect, useState } from 'react';
import { auth, db, firebaseConfigured } from './firebase';
import { onAuthStateChanged, signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut } from 'firebase/auth';
import { collection, getDocs, query, where } from 'firebase/firestore';
import { ShieldCheck, Ticket, Trophy, Headset, Menu, X, Search, ChevronRight, LockKeyhole, Sparkles, CircleHelp, LogIn, LogOut, LayoutDashboard, BadgePercent, WalletCards, CheckCircle2, Clock3 } from 'lucide-react';

const demoCampaigns = [
  { id:'demo-1', title:'Pacote gamer digital', category:'Prêmio digital', description:'Campanha demonstrativa. Confira as regras antes de participar.', price:2.5, quantity:500, sold:127, emoji:'🎮', status:'demo' },
  { id:'demo-2', title:'Créditos digitais', category:'Benefício digital', description:'Exemplo visual de campanha, sem venda ou cobrança ativa.', price:1.5, quantity:300, sold:84, emoji:'✨', status:'demo' },
  { id:'demo-3', title:'Kit surpresa digital', category:'Prêmio digital', description:'Modelo de campanha para personalizar no painel.', price:3, quantity:700, sold:256, emoji:'🎁', status:'demo' }
];

function money(v) { return Number(v || 0).toLocaleString('pt-BR',{style:'currency',currency:'BRL'}); }

export default function App() {
  const [campaigns, setCampaigns] = useState(demoCampaigns);
  const [user, setUser] = useState(null);
  const [page, setPage] = useState('home');
  const [mobileOpen, setMobileOpen] = useState(false);
  const [search, setSearch] = useState('');
  const [modal, setModal] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [notice, setNotice] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!auth) return;
    return onAuthStateChanged(auth, u => setUser(u));
  }, []);

  useEffect(() => {
    if (!db) return;
    (async () => {
      try {
        const q = query(collection(db, 'campaigns'), where('published', '==', true));
        const snap = await getDocs(q);
        if (!snap.empty) setCampaigns(snap.docs.map(d => ({id:d.id, ...d.data()})));
      } catch (e) { console.error('Não foi possível carregar campanhas', e); }
    })();
  }, []);

  const isAdmin = !!user && user.getIdTokenResult && false;
  const filtered = campaigns.filter(c => `${c.title} ${c.category || ''}`.toLowerCase().includes(search.toLowerCase()));
  const go = p => { setPage(p); setMobileOpen(false); window.scrollTo({top:0,behavior:'smooth'}); };
  async function submitAuth(e) {
    e.preventDefault(); setBusy(true); setNotice('');
    try {
      if (!auth) throw new Error('Configure o Firebase no arquivo .env antes de usar o login.');
      if (modal === 'register') await createUserWithEmailAndPassword(auth, email, password);
      else await signInWithEmailAndPassword(auth, email, password);
      setNotice('Acesso realizado.'); setModal('');
    } catch (err) { setNotice(err.message || 'Não foi possível entrar.'); }
    finally { setBusy(false); }
  }

  return <div className="app-shell">
    <div className="announcement"><Sparkles size={14}/> RifaJá • experiência digital moderna <span>Confira sempre o regulamento de cada campanha</span></div>
    <header className="topbar">
      <button className="icon-button mobile-only" onClick={() => setMobileOpen(!mobileOpen)} aria-label="Abrir menu">{mobileOpen?<X/>:<Menu/>}</button>
      <button className="brand" onClick={() => go('home')}><span className="brand-mark"><Ticket size={23}/></span><span>Rifa<span>Já</span><small>PRÊMIOS & CAMPANHAS</small></span></button>
      <nav className={mobileOpen?'nav open':'nav'}>
        <button onClick={() => go('home')}>Início</button><button onClick={() => go('campaigns')}>Campanhas</button><button onClick={() => go('winners')}>Ganhadores</button><button onClick={() => go('support')}>Suporte</button>
      </nav>
      <div className="top-actions">
        {user ? <button className="outline-button" onClick={() => go('account')}><LayoutDashboard size={16}/> Minha conta</button> : <button className="outline-button" onClick={() => {setModal('login');setNotice('')}}><LogIn size={16}/> Entrar</button>}
        <button className="primary-button" onClick={() => go('campaigns')}>Ver campanhas <ChevronRight size={16}/></button>
      </div>
    </header>

    {notice && <div className="notice" role="status">{notice}<button onClick={() => setNotice('')}><X size={15}/></button></div>}

    {page === 'home' && <>
      <main>
        <section className="hero">
          <div className="hero-copy">
            <div className="eyebrow"><span className="pulse"></span> SUA PRÓXIMA EXPERIÊNCIA COMEÇA AQUI</div>
            <h1>Novas chances.<br/><span>Grandes emoções.</span></h1>
            <p>Explore campanhas digitais, acompanhe cada etapa e encontre todas as informações em um só lugar.</p>
            <div className="hero-actions"><button className="primary-button large" onClick={() => go('campaigns')}>Explorar campanhas <ChevronRight size={18}/></button><button className="text-button" onClick={() => go('support')}>Como funciona? <CircleHelp size={16}/></button></div>
            <div className="trust-row"><span><ShieldCheck size={16}/> Ambiente protegido</span><span><CheckCircle2 size={16}/> Informações claras</span></div>
          </div>
          <div className="hero-art"><div className="glow"></div><div className="floating-chip chip-one"><Sparkles size={15}/> Experiência premium</div><div className="prize-orb"><span>🎮</span></div><div className="floating-card"><div className="mini-icon">✦</div><div><b>Prêmios digitais</b><small>Descubra as campanhas</small></div><ChevronRight size={18}/></div><div className="orbit orbit-one"></div><div className="orbit orbit-two"></div></div>
        </section>

        <section className="stats">
          <div><span className="stat-icon"><Ticket/></span><b>{campaigns.length.toString().padStart(2,'0')}</b><small>Campanhas exibidas</small></div>
          <div><span className="stat-icon"><ShieldCheck/></span><b>Segurança</b><small>Proteção por projeto</small></div>
          <div><span className="stat-icon"><Headset/></span><b>Suporte</b><small>Ajuda em um só lugar</small></div>
        </section>
        <section className="section">
          <div className="section-heading"><div><div className="eyebrow">ESCOLHA SUA EXPERIÊNCIA</div><h2>Campanhas em destaque</h2><p>Conheça as opções disponíveis e leia as regras de cada campanha.</p></div><button className="text-button" onClick={() => go('campaigns')}>Ver todas <ChevronRight size={16}/></button></div>
          <CampaignGrid campaigns={campaigns.slice(0,3)} onChoose={c => {setNotice('Esta versão está em modo de demonstração. Configure as autorizações e o pagamento antes de ativar compras.');go('campaigns')}}/>
        </section>
        <section className="feature-band"><div className="feature-icon"><LockKeyhole size={28}/></div><div><h3>Transparência em cada etapa</h3><p>Consulte regulamentos, acompanhe pedidos e fale com o suporte sempre que precisar.</p></div><button className="outline-button" onClick={() => go('support')}>Acessar suporte <ChevronRight size={16}/></button></section>
      </main>
    </>}

    {page === 'campaigns' && <main className="page-main"><div className="page-title"><div className="eyebrow">DESCUBRA</div><h1>Campanhas</h1><p>Consulte as informações e regras de cada campanha.</p></div><div className="searchbar"><Search size={18}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Buscar campanhas..."/></div><CampaignGrid campaigns={filtered} onChoose={() => setNotice('Campanhas de demonstração: compras e pagamentos estão desativados até a configuração real.')} /><div className="demo-warning">As campanhas exibidas podem ser demonstrativas. Nenhuma compra é processada nesta versão inicial.</div></main>}

    {page === 'winners' && <main className="page-main"><div className="page-title"><div className="eyebrow">RESULTADOS</div><h1>Ganhadores</h1><p>Resultados oficiais serão publicados aqui após validação e apuração documentada.</p></div><div className="empty-state"><span className="empty-icon"><Trophy size={28}/></span><h3>Nenhum resultado publicado</h3><p>Quando houver resultados verificados, eles aparecerão nesta página.</p></div></main>}

    {page === 'support' && <main className="page-main"><div className="page-title"><div className="eyebrow">ESTAMOS AQUI PARA AJUDAR</div><h1>Central de suporte</h1><p>Encontre orientação ou prepare um chamado para atendimento.</p></div><div className="support-grid"><div className="support-card"><span className="support-icon"><Headset/></span><h3>Atendimento por chamado</h3><p>O sistema completo permitirá abrir chamados, anexar informações e acompanhar respostas.</p><button className="primary-button" onClick={() => {setNotice(user?'A criação de chamados será ativada após configurar a coleção e as regras do Firestore.':'Entre ou crie uma conta para preparar seu atendimento.');setModal(user?'':'login')}}>Abrir chamado <ChevronRight size={16}/></button></div><div className="support-card"><span className="support-icon"><CircleHelp/></span><h3>Perguntas frequentes</h3><details><summary>Como acompanho um pedido?</summary><p>Entre na sua conta e consulte o histórico, quando o módulo de pedidos estiver configurado.</p></details><details><summary>Como funciona o pagamento?</summary><p>O PIX real só será habilitado após integrar e testar um provedor de pagamento.</p></details><details><summary>Como vejo os resultados?</summary><p>Os resultados verificados serão exibidos na seção Ganhadores.</p></details></div></div></main>}

    {page === 'account' && <main className="page-main"><div className="page-title"><div className="eyebrow">ÁREA SEGURA</div><h1>Minha conta</h1><p>{user?.email || 'Faça login para acessar sua conta.'}</p></div><div className="account-panel"><span className="support-icon"><ShieldCheck/></span><h3>Conta autenticada</h3><p>O painel de pedidos e os chamados serão conectados ao banco após configurar as regras e coleções.</p><button className="outline-button" onClick={() => signOut(auth).then(()=>go('home'))}><LogOut size={16}/> Sair da conta</button></div></main>}

    <footer className="footer"><div className="footer-top"><button className="brand" onClick={() => go('home')}><span className="brand-mark"><Ticket size={22}/></span><span>Rifa<span>Já</span><small>PRÊMIOS & CAMPANHAS</small></span></button><p>Informação clara e uma experiência digital organizada.</p></div><div className="footer-links"><button onClick={() => go('support')}>Suporte</button><a href="#termos" onClick={e=>{e.preventDefault();setNotice('Adicione e revise os termos jurídicos antes de publicar.')}}>Termos e regras</a><a href="#privacidade" onClick={e=>{e.preventDefault();setNotice('Adicione a política de privacidade e os procedimentos LGPD antes de publicar.')}}>Privacidade</a><button onClick={() => setModal('login')}>Minha conta</button></div><small className="copyright">© {new Date().getFullYear()} RifaJá. Versão inicial em desenvolvimento.</small></footer>

    {modal && <div className="modal-backdrop" onClick={() => setModal('')}><div className="auth-modal" onClick={e=>e.stopPropagation()}><button className="modal-close" onClick={()=>setModal('')}><X/></button><div className="modal-logo"><span className="brand-mark"><Ticket/></span></div><div className="eyebrow">{modal==='register'?'COMECE AGORA':'BEM-VINDO DE VOLTA'}</div><h2>{modal==='register'?'Criar conta':'Entrar no RifaJá'}</h2><p>Use sua conta para acessar os recursos disponíveis.</p><form onSubmit={submitAuth}><label>E-mail<input type="email" required value={email} onChange={e=>setEmail(e.target.value)} placeholder="voce@email.com"/></label><label>Senha<input type="password" required minLength="6" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Mínimo de 6 caracteres"/></label><button className="primary-button full" disabled={busy}>{busy?'Aguarde...':modal==='register'?'Criar conta':'Entrar'}</button></form><button className="switch-auth" onClick={()=>{setModal(modal==='register'?'login':'register');setNotice('')}}>{modal==='register'?'Já tem conta? Entrar':'Não tem conta? Criar cadastro'}</button>{!firebaseConfigured&&<div className="inline-warning">Configure o Firebase para ativar a autenticação.</div>}</div></div>}
  </div>;
}

function CampaignGrid({campaigns,onChoose}) {
  if (!campaigns.length) return <div className="empty-state"><Search/><h3>Nenhuma campanha encontrada</h3><p>Tente outro termo de busca.</p></div>;
  return <div className="campaign-grid">{campaigns.map((c,i)=><article className="campaign-card" key={c.id}><div className={`campaign-art art-${i%3}`}><span className="campaign-tag">{c.category || 'Campanha digital'}</span><span className="campaign-emoji">{c.emoji || '🎁'}</span><span className="art-sparkle">✦</span></div><div className="campaign-content"><div className="campaign-topline"><span className="status-dot"></span><span>Campanha demonstrativa</span></div><h3>{c.title}</h3><p>{c.description || 'Confira os detalhes e as regras desta campanha.'}</p><div className="price-row"><div><small>Valor por número</small><b>{money(c.price)}</b></div><div className="remaining"><small>Números</small><b>{Number(c.quantity||0).toLocaleString('pt-BR')}</b></div></div><div className="progress-label"><span>Exemplo de progresso</span><b>{Math.min(100,Math.round((c.sold||0)/(c.quantity||1)*100))}%</b></div><div className="progress"><span style={{width:`${Math.min(100,Math.round((c.sold||0)/(c.quantity||1)*100))}%`}}/></div><button className="card-button" onClick={()=>onChoose(c)}>Ver detalhes <ChevronRight size={16}/></button></div></article>)}</div>
}
