const { onCall, HttpsError } = require('firebase-functions/v2/https');
const { onDocumentCreated } = require('firebase-functions/v2/firestore');
const { initializeApp } = require('firebase-admin/app');
const { getFirestore, FieldValue } = require('firebase-admin/firestore');
const { getAuth } = require('firebase-admin/auth');

initializeApp();
const db = getFirestore();

function requireAdmin(request) {
  if (!request.auth || request.auth.token.admin !== true) {
    throw new HttpsError('permission-denied', 'Acesso administrativo não autorizado.');
  }
}

// Run this only from a trusted, authenticated owner setup workflow.
// Never expose service-account credentials in the browser.
exports.setOwnerClaim = onCall(async (request) => {
  if (!request.auth) throw new HttpsError('unauthenticated', 'Faça login.');
  const setup = await db.doc('privateSetup/owner').get();
  if (setup.exists) throw new HttpsError('failed-precondition', 'O proprietário já foi configurado.');
  // Deliberately requires an operator to deploy a verified one-time setup process.
  // Do not enable a public bootstrap endpoint with a shared secret.
  throw new HttpsError('failed-precondition', 'Configure a custom claim admin=true usando um procedimento seguro do Firebase Admin SDK, executado pelo proprietário em ambiente confiável.');
});

exports.adminHealthCheck = onCall(async (request) => {
  requireAdmin(request);
  return { ok: true, message: 'Sessão administrativa autorizada.' };
});

// Placeholder is intentionally disabled until a real payment provider is selected.
// Do not accept real payments until provider API + signed webhook verification are implemented.
exports.createPixCharge = onCall(async (request) => {
  if (!request.auth) throw new HttpsError('unauthenticated', 'Faça login para continuar.');
  throw new HttpsError('failed-precondition', 'PIX ainda não configurado. Escolha um provedor e implemente a criação da cobrança e seu webhook assinado antes de ativar pagamentos.');
});

// Example server-side audit event for support tickets; sensitive content is not copied to logs.
exports.auditSupportTicketCreated = onDocumentCreated('supportTickets/{ticketId}', async (event) => {
  const data = event.data?.data();
  if (!data) return;
  await db.collection('auditLogs').add({
    action: 'support_ticket_created',
    targetId: event.params.ticketId,
    userId: data.userId || null,
    createdAt: FieldValue.serverTimestamp()
  });
});
